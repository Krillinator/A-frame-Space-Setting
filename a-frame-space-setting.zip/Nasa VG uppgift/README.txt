To get the complete HDU please import both:

HDU_lowRez_part1.obj
HDU_lowRez_part2.obj

Both files will read their .mtl file and load the textures for each piece.

Included are other files that work as a src file for the respective entities and objects.

Most of which was found at pixabay. 


Feel free to look around.

This was done in a less than a day and the code is all in one file. 
So it gets pretty messy. 
